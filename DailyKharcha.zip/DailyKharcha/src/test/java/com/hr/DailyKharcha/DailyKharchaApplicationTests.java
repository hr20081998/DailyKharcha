package com.hr.DailyKharcha;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DailyKharchaApplicationTests {

	@Test
	void contextLoads() {
	}

}

package com.hr.DailyKharcha;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DailyKharchaApplication {

	public static void main(String[] args) {
		SpringApplication.run(DailyKharchaApplication.class, args);
	}

}
